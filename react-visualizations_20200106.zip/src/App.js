import React from "react";
import "./App.css";
import {
  LineGraph,
  BarGraph,
  PieChart,
  XAxis,
  YAxis,
  Grid,
  ScatterPlot,
  Label
} from "./components/Visualizations";
const data = [
  { x: 0, y: 65, color: "#FF00FF", label: "Dec", tooltip: "tooltip" },
  { x: 1, y: 2, color: "#FF00FF", label: "January", shape: "circle", size: 7 },
  { x: 2, y: 47, label: "Feb", tooltip: "tooltip", shape: "hexagon", size: 4 },
  { x: 3, y: 55, label: "Mar", shape: "club", size: 4 },
  { x: 4, y: 42, label: "Apr", shape: "spade", size: 4 },
  { x: 5, y: 65, label: "May", shape: "heart", size: 4 },
  { x: 6, y: 55, label: "Jun", shape: "#", size: 6 * 3 },
  { x: 7, y: 62, label: "Jul", shape: "", size: 6 * 3 },
  { x: 8, y: 82, label: "Aug" },
  { x: 9, y: 75, label: "Sep" },
  { x: 10, y: 53, label: "Oct" },
  { x: 11, y: 33, label: "Nov" },
  { x: 12, y: 100, label: "Dec" },
  { x: 13, y: 87, label: "Jan" }
];

const yAxisTicks = [
  { y: 25, label: "25 Million" },
  { y: 50, label: "50 Million" },
  { y: 75, label: "75 Million" },
  { y: 100, label: "100 Million" }
];
const pieData = [
  { category: "A", percentage: 70, tooltip: "70" },
  { category: "B", percentage: 120, tooltip: "120" },
  { category: "C", percentage: 380, tooltip: "380" },
  { category: "D", percentage: 480, tooltip: "480" }
];

function App() {
  return (
    <div id="App" style={{ margin: "10px" }}>
      <svg>
        <Label x={150} y={100} rotation={45}>
          Hell5556
        </Label>
      </svg>
      <div id="Demo-Multi" style={{ margin: "10px" }}>
        <svg width={470} height={300}>
          <Grid
            x={60}
            y={10}
            width={400}
            height={200}
            rows={13}
            columns={4}
            data={data}
          />
          <YAxis x={60} y={10} height={200} rangeMax={100} data={yAxisTicks} />
          <XAxis x={60} y={210} width={400} data={data} />

          <BarGraph
            x={60}
            y={10}
            width={400}
            height={200}
            yMin={0}
            yMax={100}
            xMin={0}
            xMax={13}
            filterXMin={1}
            filterXMax={12}
            defaultColor={"red"}
            tooltip="hello"
            data={data}
          />
          <LineGraph
            x={60}
            y={10}
            width={400}
            height={200}
            bezier={true}
            yMin={0}
            yMax={100}
            xMin={0}
            xMax={13}
            filterXMin={0}
            filterXMax={13}
            defaultColor={"red"}
            tooltip="line"
            data={data}
          />
          <ScatterPlot
            x={60}
            y={10}
            width={400}
            height={200}
            xMin={0}
            xMax={13}
            yMin={0}
            yMax={100}
            data={data}
          />
        </svg>
      </div>
      <div id="Demo-PieChart" style={{ margin: "10px" }}>
        <svg width={200} height={200}>
          <PieChart data={pieData} size={200} />
        </svg>
      </div>
    </div>
  );
}

export default App;

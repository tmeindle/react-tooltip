//https://vkbansal.me/blog/pie-donut-chart-without-d3/

export const arcString = (
  startAngle,
  endAngle,
  outerRadius,
  innerRadius,
  strokeWidth = 0
) => {
  const arcLength = endAngle - startAngle;
  const largeArc = arcLength > Math.PI;
  const fullCircle = arcLength >= 2 * Math.PI;

  const sinAlpha = Math.sin(startAngle);
  const cosAlpha = Math.cos(startAngle);
  const sinBeta = Math.sin(fullCircle ? endAngle - 0.0001 : endAngle + 0.01);
  const cosBeta = Math.cos(fullCircle ? endAngle - 0.0001 : endAngle + 0.01);

  const P = {
    x: outerRadius + outerRadius * sinAlpha + strokeWidth / 2,
    y: outerRadius - outerRadius * cosAlpha + strokeWidth / 2
  };

  const Q = {
    x: outerRadius + outerRadius * sinBeta + strokeWidth / 2,
    y: outerRadius - outerRadius * cosBeta + strokeWidth / 2
  };

  const R = {
    x: outerRadius + innerRadius * sinBeta + strokeWidth / 2,
    y: outerRadius - innerRadius * cosBeta + strokeWidth / 2
  };

  const S = {
    x: outerRadius + innerRadius * sinAlpha + strokeWidth / 2,
    y: outerRadius - innerRadius * cosAlpha + strokeWidth / 2
  };

  return innerRadius > 0
    ? `M${P.x},${P.y}
    A${outerRadius},${outerRadius} 0 ${largeArc ? "1,1" : "0,1"} ${Q.x},${Q.y}
    ${fullCircle ? "M" : "L"}${R.x},${R.y}
    A${innerRadius}, ${innerRadius} 0 ${largeArc ? "1,0" : "0,0"} ${S.x},${S.y}
    ${fullCircle ? "M" : "L"}${P.x},${P.y}`.replace("\n", " ")
    : `M${P.x},${P.y} 
    A${outerRadius},${outerRadius} 0 ${largeArc ? "1,1" : "0,1"} ${Q.x},${Q.y} 
    ${fullCircle ? "M" : "L"}${R.x},${R.y}  
    ${fullCircle ? "M" : "L"}${P.x},${P.y}`.replace("\n", " ");
};

export default arcString;

const scaleValueLinear = (minNorm, maxNorm, minValue, maxValue) => {
  const scalarCoeff = (maxNorm - minNorm) / (maxValue - minValue);

  return function(value) {
    return scalarCoeff * (value - minValue) + minValue;
  };
};

export default scaleValueLinear;

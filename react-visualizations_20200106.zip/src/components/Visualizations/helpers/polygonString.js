const polygonString = (
  numberOfSides = 6,
  size = 20,
  cx = 25,
  cy = 25,
  rotation = 0
) => {
  let startOffset = (rotation / 360) * (2 * Math.PI) - 0.5 * Math.PI;
  let angle = (2 * Math.PI) / numberOfSides;
  let path = `M${cx + size * Math.cos(startOffset)},${cy +
    size * Math.sin(startOffset)}`;
  for (var i = 1; i < numberOfSides; i += 1) {
    path += `L${cx + size * Math.cos(startOffset + i * angle)},
      ${cy + size * Math.sin(startOffset + i * angle)}`;
  }
  path += "Z";
  return path;
};

export default polygonString;

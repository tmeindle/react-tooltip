import React, { useRef } from "react";
import styled from "styled-components";
import Tooltip from "../Tooltip/Tooltip";

import linePath from "../helpers/linePath";

const Path = styled.path`
  d: ${props => props.styled.d};
  fill: ${props => props.styled.fill};
  stroke: ${props => props.styled.stroke};
  stroke-width: ${props => props.styled.strokeWidth};
  stroke-dasharray: ${props => props.styled.strokeDasharray};
  alignment-baseline: ${props => props.styled.alignmentBaseline};
`;

const LinePath = ({
  stroke = "#0000FF",
  strokeWidth = 1,
  strokeDasharray,
  points,
  bezier = false,
  alignmentBaseline = "auto",

  tooltip,
  tooltipActive = false,
  tooltipStyle = { position: "top" },

  onMouseEnter,
  onMouseLeave,
  onMouseOver,
  onMouseOut
}) => {
  const pathRef = useRef();
  const styled = {
    d: `path('${linePath(points, bezier)}')`,
    alignmentBaseline,
    fill: "none",
    strokeWidth,
    stroke,
    strokeDasharray
  };

  return (
    <>
      <Path
        key="path"
        ref={pathRef}
        styled={styled}
        onMouseEnter={onMouseEnter}
        onMouseLeave={onMouseLeave}
        onMouseOver={onMouseOver}
        onMouseOut={onMouseOut}
      />
      <Tooltip
        key="tooltip"
        parent={pathRef}
        active={tooltipActive}
        {...tooltipStyle}
      >
        {tooltip}
      </Tooltip>
    </>
  );
};

export default LinePath;

import React, { useRef, useState, useLayoutEffect } from "react";
import styled from "styled-components";
import Tooltip from "../Tooltip/Tooltip";

const Text = styled.text`
  fill: ${props => props.styled.fill};
  stroke: ${props => props.styled.stroke};
  stroke-width: ${props => props.styled.strokeWidth};

  font-size: ${props => props.styled.fontSize}px;
  alignment-baseline: ${props => props.styled.alignmentBaseline};
  transform: ${props => props.styled.transform};
  text-anchor: ${props => props.styled.textAnchor};
  transform-origin: ${props => props.styled.transformOrigin};
`;

const Label = ({
  x = 0,
  y = 0,
  maxWidth = 100,
  stroke = "black",
  strokeWidth = 1,
  fill = "red",
  ellipsis = false,

  fontSize = 11,
  dominantBaseline = "central",
  alignmentBaseline = "auto",
  anchor = "middle",
  rotation = 0,
  textLength,
  tooltip,
  tooltipActive,
  tooltipStyle = {},

  onMouseEnter,
  onMouseLeave,
  onMouseOver,
  onMouseOut,

  children
}) => {
  const labelRef = useRef();
  const [clipped, setClipped] = useState(false);
  const [hover, setHover] = useState(false);

  const handleMouseEnter = e => {
    setHover(true);
    if (onMouseEnter) onMouseEnter(e);
  };

  const handleMouseLeave = e => {
    setHover(false);
    if (onMouseLeave) onMouseLeave(e);
  };

  useLayoutEffect(() => {
    if (maxWidth === undefined || !labelRef || !labelRef.current) return;
    let computedLength = labelRef.current.getComputedTextLength();
    let text = labelRef.current.textContent;

    if (computedLength > maxWidth && text.length > 0) {
      let l = (maxWidth / computedLength) * text.length;
      text = text.slice(0, l) + "\u2026";
      labelRef.current.textContent = text;
      computedLength = labelRef.current.getComputedTextLength();

      while (computedLength > maxWidth && text.length > 1) {
        text = ellipsis
          ? text.slice(0, -2) + "\u2026"
          : (text = text.slice(0, -1));
        labelRef.current.textContent = text;
        computedLength = labelRef.current.getComputedTextLength();
      }

      if (computedLength > maxWidth && text.length === 1) {
        labelRef.current.textContent = "";
      }
      setClipped(true);
    }
  }, [labelRef, maxWidth, ellipsis]);

  let textStyle = {
    fill: fill,
    alignmentBaseline: alignmentBaseline,
    dominantBaseline,
    textAnchor: anchor,
    strokeWidth: strokeWidth,
    stroke: stroke,
    fontSize: fontSize,
    transform: rotation ? `rotate(${rotation}deg)` : undefined,
    transformOrigin: rotation ? `${x}px ${y}px` : undefined
  };

  return (
    <>
      <Text
        key="text"
        ref={labelRef}
        x={x}
        y={y}
        styled={textStyle}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        onMouseOver={onMouseOver}
        onMouseOut={onMouseOut}
      >
        {children}
      </Text>
      <Tooltip
        key="tooltip"
        parent={labelRef}
        active={tooltipActive === undefined ? hover && clipped : tooltipActive}
        {...tooltipStyle}
      >
        {tooltipActive === undefined && !tooltip && clipped && children
          ? children
          : tooltip}
      </Tooltip>
    </>
  );
};

export default Label;

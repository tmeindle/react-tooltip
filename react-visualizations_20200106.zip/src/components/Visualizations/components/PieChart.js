import React, { useState, useRef } from "react";
import Arc from "./Arc";
import indexOf from "../helpers/indexOf";
import Tooltip from "../Tooltip/Tooltip";

const PieChart = ({
  startAngle = 0,
  innerRadius = 0,
  size = 0,
  data = [],
  stroke = "black",
  strokeWidth = 10,
  strokeOpacity = 1,
  colorScale = ["#AAAAAA", "#999999", "#888888"],

  tooltipKey = "tooltip",
  tooltipStyle = {},

  onMouseEnter,
  onMouseLeave,
  onMouseOver,
  onMouseOut
}) => {
  const [hoverIndex, setHoverIndex] = useState();
  const [tooltip, setTooltip] = useState();
  const handleMouseEnter = e => {
    const arcIndex = indexOf(e.currentTarget);
    setTooltip(data[arcIndex][tooltipKey]);
    setHoverIndex(arcIndex);
    onMouseEnter && onMouseEnter(e, arcIndex);
  };

  const handleMouseLeave = e => {
    setHoverIndex();
    onMouseLeave && onMouseLeave(e, indexOf(e.currentTarget));
  };

  const outerRadius = size / 2 - strokeWidth / 2;
  const total = data.reduce((p, c) => p + c.percentage, 0);
  const startOffset = (startAngle / 360) * total;
  const ref = useRef();
  let offset = startOffset;
  let pie =
    data.length === 0 ? null : (
      <g ref={ref}>
        {data.map((item, index) => {
          const endAngle = offset + (item.percentage / total) * 2 * Math.PI;
          let path = (
            <Arc
              key={index}
              startAngle={offset}
              endAngle={endAngle}
              outerRadius={outerRadius}
              innerRadius={innerRadius}
              stroke={stroke}
              strokeWidth={strokeWidth}
              strokeOpacity={strokeOpacity}
              fill={colorScale[index % colorScale.length]}
              tooltip={item[tooltipKey]}
              //tooltipActive={index === hoverIndex}
              tooltipStyle={tooltipStyle}
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
              onMouseOver={onMouseOver}
              onMouseOut={onMouseOut}
            />
          );
          offset = endAngle;
          return path;
        })}
      </g>
    );
  return (
    <>
      {pie}
      <Tooltip
        key="tooltip"
        parent={ref}
        active={!!hoverIndex}
        {...tooltipStyle}
      >
        {tooltip}
      </Tooltip>
    </>
  );
};

export default PieChart;

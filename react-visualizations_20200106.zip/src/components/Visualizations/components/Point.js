import React, { useRef } from "react";
import styled from "styled-components";
import Tooltip from "../Tooltip/Tooltip";

const Circle = styled.circle`
  ${props =>
    props.styled.cx !== undefined ? "cx: " + props.styled.cx + "px;" : ""}
  ${props =>
    props.styled.cy !== undefined ? "cy: " + props.styled.cy + "px;" : ""}
  ${props =>
    props.styled.r !== undefined ? "r: " + props.styled.r + "px;" : ""}

  fill: ${props => props.styled.fill};
  stroke: ${props => props.styled.stroke};
  stroke-width: ${props => props.styled.strokeWidth};
`;

const Point = ({
  x,
  y,
  stroke = "black",
  strokeWidth = 1,
  fill = "red",
  size = 15,

  tooltip,
  tooltipActive = false,
  tooltipStyle = {},

  onMouseEnter,
  onMouseLeave,
  onMouseOver,
  onMouseOut
}) => {
  const circleRef = useRef();

  const styled = {
    cx: x,
    cy: y,
    r: size / 2,
    fill,
    stroke,
    strokeWidth
  };

  return (
    <>
      <Circle
        key="point"
        ref={circleRef}
        styled={styled}
        onMouseEnter={onMouseEnter}
        onMouseLeave={onMouseLeave}
        onMouseOver={onMouseOver}
        onMouseOut={onMouseOut}
      />
      <Tooltip
        key="tooltip"
        parent={circleRef}
        active={tooltipActive}
        {...tooltipStyle}
      >
        {tooltip}
      </Tooltip>
    </>
  );
};

export default Point;

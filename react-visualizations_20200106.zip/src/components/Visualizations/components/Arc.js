import React, { useRef } from "react";
import styled from "styled-components";
import Tooltip from "../Tooltip/Tooltip";
import arcString from "../helpers/arcString";

const Path = styled.path`
  d: ${props => props.styled.d};
  fill: ${props => props.styled.fill};
  stroke: ${props => props.styled.stroke};
  stroke-width: ${props => props.styled.strokeWidth};
`;

const Arc = ({
  startAngle,
  endAngle,
  outerRadius,
  innerRadius,
  stroke,
  strokeWidth,
  strokeOpacity,
  fill,

  tooltip,
  tooltipActive = false,
  tooltipStyle = {},

  onMouseEnter,
  onMouseLeave,
  onMouseOver,
  onMouseOut
}) => {
  const arcRef = useRef();
  const styled = {
    d: `path('${arcString(
      startAngle,
      endAngle,
      outerRadius,
      innerRadius,
      strokeWidth
    )}')`,
    stroke,
    strokeWidth,
    strokeOpacity,
    fill
  };

  return (
    <>
      <Path
        ref={arcRef}
        key="arc"
        styled={styled}
        onMouseEnter={onMouseEnter}
        onMouseLeave={onMouseLeave}
        onMouseOver={onMouseOver}
        onMouseOut={onMouseOut}
      />
      <Tooltip
        key="tooltip"
        parent={arcRef}
        active={tooltipActive}
        {...tooltipStyle}
      >
        {tooltip}
      </Tooltip>
    </>
  );
};

export default Arc;

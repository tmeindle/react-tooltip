import React, { useRef } from "react";
import Tooltip from "../Tooltip/Tooltip";
import styled from "styled-components";

const Rect = styled.rect`
  ${props =>
    props.styled.x !== undefined ? "x: " + props.styled.x + "px;" : ""}
  ${props =>
    props.styled.y !== undefined ? "y: " + props.styled.y + "px;" : ""}
  ${props =>
    props.styled.rx !== undefined ? "rx: " + props.styled.rx + "px;" : ""}
  ${props =>
    props.styled.ry !== undefined ? "ry: " + props.styled.ry + "px;" : ""}
  ${props =>
    props.styled.width !== undefined
      ? "width: " + props.styled.width + "px;"
      : ""}
  ${props =>
    props.styled.height !== undefined
      ? "height: " + props.styled.height + "px;"
      : ""}

  fill: ${props => props.styled.fill};
  stroke: ${props => props.styled.stroke};
  stroke-width: ${props => props.styled.strokeWidth};
`;

const Bar = ({
  x,
  y,
  height,
  width,
  fill = "red",
  stroke = "black",
  strokeWidth = 1,

  tooltip,
  tooltipActive = false,
  tooltipStyle = {},

  onMouseEnter,
  onMouseLeave,
  onMouseOver,
  onMouseOut
}) => {
  const barRef = useRef();

  const styled = {
    x,
    y: y + strokeWidth / 2,
    width,
    height: height - strokeWidth - 0.5,
    fill,
    stroke,
    strokeWidth
  };

  return (
    <>
      <Rect
        key={"rect"}
        ref={barRef}
        styled={styled}
        onMouseEnter={onMouseEnter}
        onMouseLeave={onMouseLeave}
        onMouseOver={onMouseOver}
        onMouseOut={onMouseOut}
      />
      <Tooltip
        key="tooltip"
        parent={barRef}
        active={tooltipActive}
        {...tooltipStyle}
      >
        {tooltip}
      </Tooltip>
    </>
  );
};

export default Bar;

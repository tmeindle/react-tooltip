import React from "react";
import Label from "./Label";
import LinePath from "./LinePath";
import scaleLinear from "../helpers/scaleLinear";

const XAxisLabels = ({
  x = 0,
  y = 0,
  width = 100,
  alignmentBaseline = "text-before-edge",
  textAnchor = "end",
  textRotation = -45,
  textStrokeWidth = 1,
  textStroke = "black",
  fontSize = 11,

  data,
  labelKey = "label",
  xKey = "x",
  xMin = 0,
  xMax = 13,
  filterXMin = 1,
  filterXMax = 12,
  colorKey = "color"
}) => {
  if (!data) return null;
  const scaleXValue = scaleLinear(0, width, xMin, xMax);
  const labels = data
    .filter(
      dataItem =>
        (filterXMin === undefined || dataItem[xKey] >= filterXMin) &&
        (filterXMax === undefined || dataItem[xKey] <= filterXMax)
    )
    .map((dataItem, index) => {
      let textHoriz = scaleXValue(dataItem[xKey]);
      let x1 = textHoriz + x;

      let textStyle = {
        alignmentBaseline: alignmentBaseline,
        anchor: textAnchor,
        strokeWidth: textStrokeWidth,
        stroke: textStroke,
        fontSize: fontSize,
        rotation: textRotation
      };

      return (
        <Label key={index} x={x1} y={y} {...textStyle}>
          {dataItem[labelKey]}
        </Label>
      );
    });
  return labels;
};

const XAxis = props => {
  let { x = 0, y = 0, width = 100 } = props;

  const axis = (
    <LinePath
      points={[
        [x, y],
        [x + width, y]
      ]}
    />
  );

  return (
    <g>
      {axis}
      <XAxisLabels {...props} />
    </g>
  );
};

export default XAxis;

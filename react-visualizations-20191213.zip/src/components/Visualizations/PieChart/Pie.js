import React from "react";
import Arc from "./Arc";

const Pie = ({
  startAngle = 0,
  innerRadius = 0,
  size = 0,
  data = [],
  stroke = "black",
  strokeWidth = 10,
  strokeOpacity = 1,
  colorScale = ["#AAAAAA", "#999999", "#888888"]
}) => {
  const outerRadius = size / 2 - strokeWidth / 2;
  const total = data.reduce((p, c) => p + c.percentage, 0);
  const startOffset = (startAngle / 360) * total;

  let offset = startOffset;
  let pie =
    data.length === 0 ? null : (
      <g>
        {data.map((item, index) => {
          const endAngle = offset + (item.percentage / total) * 2 * Math.PI;
          let path = (
            <Arc
              key={index}
              startAngle={offset}
              endAngle={endAngle}
              outerRadius={outerRadius}
              innerRadius={innerRadius}
              stroke={stroke}
              strokeWidth={strokeWidth}
              strokeOpacity={strokeOpacity}
              fill={colorScale[index % colorScale.length]}
            />
          );
          offset = endAngle;
          return path;
        })}
      </g>
    );
  return pie;
};

export default Pie;

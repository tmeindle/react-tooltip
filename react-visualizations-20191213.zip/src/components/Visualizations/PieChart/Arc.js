import React from "react";
import arcString from "../svgHelpers/arcString";
const Arc = ({
  startAngle,
  endAngle,
  outerRadius,
  innerRadius,
  stroke,
  strokeWidth,
  strokeOpacity,
  fill
}) => {
  const start = startAngle;
  const end = endAngle;
  return (
    <path
      d={arcString(start, end, outerRadius, innerRadius, strokeWidth)}
      stroke={stroke}
      strokeWidth={strokeWidth}
      strokeOpacity={strokeOpacity}
      fill={fill}
    />
  );
};

export default Arc;

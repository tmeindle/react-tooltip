import React, { useState } from "react";
import Tooltip from "../Tooltip/Tooltip";

const Bar = ({
  x,
  y,
  height,
  width,
  fill = "black",
  stroke = "black",
  strokeWidth = 1,
  tooltip = null
}) => {
  const barRef = React.createRef();
  const [hover, setHover] = useState(false);

  let rect = (
    <rect
      key="rect"
      ref={barRef}
      x={x}
      y={y + strokeWidth / 2}
      width={width}
      height={height - strokeWidth - 0.5}
      stroke={stroke}
      strokeWidth={strokeWidth}
      fill={fill}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    />
  );
  let tip = (
    <Tooltip key="tooltip" parent={barRef} active={tooltip && hover}>
      {tooltip}
    </Tooltip>
  );
  return (
    <>
      {rect}
      {tooltip ? tip : null}
    </>
  );
};

export default Bar;

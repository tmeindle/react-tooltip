import React from "react";
import Bars from "./Bars";
const scaleValue = (value, minNorm, maxNorm, minValue, maxValue) => {
  return (
    ((maxNorm - minNorm) / (maxValue - minValue)) * (value - minValue) +
    minValue
  );
};

const BarGraph = ({
  x = 0,
  y = 0,
  width = 100,
  height = 100,
  barWidth = 5,
  filterXMin = 1,
  filterXMax = 12,
  rangeXMin = 0,
  rangeXMax = 13,
  rangeYMin = 0,
  rangeYMax = 100,
  defaultColor = "#FF00FF",
  data,
  yKey = "y",
  xKey = "x",
  colorKey = "color",
  tooltip
}) => {
  const bars = data
    .filter(
      dataItem =>
        (!filterXMin === undefined || dataItem[xKey] >= filterXMin) &&
        (filterXMax === undefined || dataItem[xKey] <= filterXMax)
    )
    .map((dataItem, index) => {
      let barHoriz =
        scaleValue(dataItem[xKey], 0, width, rangeXMin, rangeXMax) + x;
      let x1 = barHoriz - barWidth / 2;

      let barHeight = scaleValue(
        dataItem[yKey],
        0,
        height,
        rangeYMin,
        rangeYMax - rangeYMin
      );
      let y1 = height - barHeight + y;

      return [
        x1,
        y1,
        barWidth,
        barHeight,
        dataItem[colorKey] ? dataItem[colorKey] : defaultColor
      ];
    });

  return <Bars bars={bars} tooltip={tooltip} />;
};

export default BarGraph;

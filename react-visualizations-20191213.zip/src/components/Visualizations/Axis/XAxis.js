import React from "react";
import Path from "../LineGraph/Path";

const scaleValue = (value, minNorm, maxNorm, minValue, maxValue) => {
  return (
    ((maxNorm - minNorm) / (maxValue - minValue)) * (value - minValue) +
    minValue
  );
};

const XAxisLabels = ({
  data,
  labelKey = "label",
  valueKey = "x",
  colorKey = "color",
  x = 0,
  y = 0,
  width = 100,
  alignmentBaseline = "text-before-edge",
  textAnchor = "middle",
  rangeMin = 0,
  rangeMax = 13,
  filterMin = 1,
  filterMax = 12,
  rotation = 0,
  textStrokeWidth = 1,
  tooltip
}) => {
  if (!data) return null;
  const labels = data
    .filter(
      dataItem =>
        (!filterMin === undefined || dataItem[valueKey] >= filterMin) &&
        (filterMax === undefined || dataItem[valueKey] <= filterMax)
    )
    .map((dataItem, index) => {
      let textHoriz = scaleValue(
        dataItem[valueKey],
        0,
        width,
        rangeMin,
        rangeMax
      );
      let x1 = textHoriz + x;

      let textStyle = {
        alignmentBaseline: alignmentBaseline,
        textAnchor: textAnchor,
        strokeWidth: textStrokeWidth,
        fill: "white",
        stroke: "black",
        fontSize: "11"
      };
      if (rotation) textStyle.transform = `rotate(${rotation}, ${x1}, ${y})`;
      return (
        <text key={index} x={x1} y={y} style={textStyle}>
          {dataItem[labelKey]}
        </text>
      );
    });
  return labels;
};

const XAxis = props => {
  let { x = 0, y = 0, width = 100 } = props;

  const axis = (
    <Path
      points={[
        [x, y],
        [x + width, y]
      ]}
    />
  );

  return (
    <g>
      {axis}
      <XAxisLabels {...props} />
    </g>
  );
};

export default XAxis;

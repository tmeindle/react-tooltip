import React from "react";
import Path from "../LineGraph/Path";

const scaleValue = (value, minNorm, maxNorm, minValue, maxValue) => {
  return (
    ((maxNorm - minNorm) / (maxValue - minValue)) * (value - minValue) +
    minValue
  );
};

const YAxisLabels = ({
  data,
  labelKey = "label",
  valueKey = "y",
  colorKey = "color",
  x = 0,
  y = 0,
  height = 100,
  alignmentBaseline = "bottom",
  textAnchor = "end",
  rangeMin = 0,
  rangeMax = 100,
  filterMin = 0,
  filterMax = 100,
  rotation = 0,
  textStrokeWidth = 1,
  tooltip
}) => {
  if (!data) return null;
  const labels = data
    .filter(
      dataItem =>
        (!filterMin === undefined || dataItem[valueKey] >= filterMin) &&
        (filterMax === undefined || dataItem[valueKey] <= filterMax)
    )
    .map((dataItem, index) => {
      let y1 =
        height -
        scaleValue(
          dataItem[valueKey],
          0,
          height,
          rangeMin,
          rangeMax - rangeMin + 1
        );

      let textStyle = {
        alignmentBaseline: alignmentBaseline,
        textAnchor: textAnchor,
        strokeWidth: textStrokeWidth,
        fill: "black",
        stroke: "black",
        fontSize: "11"
      };
      if (rotation) textStyle.transform = `rotate(${rotation}, ${y1}, ${y})`;
      return (
        <text key={index} x={x} y={y + y1} style={textStyle}>
          {dataItem[labelKey]}
        </text>
      );
    });
  return labels;
};

const YAxis = props => {
  let { x = 0, y = 0, height = 100 } = props;

  const axis = (
    <Path
      points={[
        [x, y],
        [x, y + height]
      ]}
    />
  );

  return (
    <g>
      <g>
        <YAxisLabels {...props} />
      </g>
      <g>{axis}</g>
    </g>
  );
};

export default YAxis;

import React from "react";
import Point from "./Point";
const scaleValue = (value, minNorm, maxNorm, minValue, maxValue) => {
  return (
    ((maxNorm - minNorm) / (maxValue - minValue)) * (value - minValue) +
    minValue
  );
};

const ScatterPlot = ({
  x = 0,
  y = 0,
  width = 100,
  height = 100,
  pointSize = 5,
  filterXMin = 1,
  filterXMax = 12,
  rangeXMin = 0,
  rangeXMax = 13,
  rangeYMin = 0,
  rangeYMax = 100,
  defaultColor = "#FF00FF",
  data,
  yKey = "y",
  xKey = "x",
  colorKey = "color",
  tooltip
}) => {
  const points = data
    .filter(
      dataItem => dataItem[xKey] >= filterXMin && dataItem[xKey] <= filterXMax
    )
    .map((dataItem, index) => {
      let pointHoriz =
        scaleValue(dataItem[xKey], 0, width, rangeXMin, rangeXMax) + x;
      let x1 = pointHoriz; // - pointSize / 2;

      let pointVert = scaleValue(
        dataItem[yKey],
        0,
        height,
        rangeYMin,
        rangeYMax - rangeYMin
      );
      let y1 = height - pointVert + y;

      return [x1, y1, dataItem[colorKey] ? dataItem[colorKey] : defaultColor];
    });

  return (
    <g>
      {points.map(([x1, y1], index) => (
        <Point key={index} x={x1} y={y1} />
      ))}
    </g>
  );
};

export default ScatterPlot;

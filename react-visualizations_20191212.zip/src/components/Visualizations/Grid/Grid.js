import React from "react";

const Grid = ({
  x = 0,
  y = 0,
  rows = 10,
  columns = 10,
  width = 100,
  height = 100,
  verticalLineStroke = "black",
  verticalLineOpacity = 0.5,
  verticalLineStrokeWidth = 1,
  verticalLineDashArray = [2, 2],
  horizontalLineStroke = "black",
  horizontalLineOpacity = 0.5,
  horizontalLineStrokeWidth = 1,
  horizontalLineDashArray = [2, 2]
}) => {
  let rects = [];
  let vLines = [];
  let hLines = [];

  let i, j;
  let rowWidth = width / rows;
  let columnHeight = height / columns;

  for (j = 0; j < rows + 1; j++) {
    vLines.push(
      <line
        x1={x + j * rowWidth}
        y1={y}
        x2={x + j * rowWidth}
        y2={y + height}
        stroke={verticalLineStroke}
        opacity={verticalLineOpacity}
        strokeWidth={verticalLineStrokeWidth}
        strokeDasharray={verticalLineDashArray}
      />
    );
  }

  for (j = 0; j < columns; j++) {
    hLines.push(
      <line
        x1={x}
        y1={y + j * columnHeight}
        x2={x + width}
        y2={y + j * columnHeight}
        stroke={horizontalLineStroke}
        opacity={horizontalLineOpacity}
        strokeWidth={horizontalLineStrokeWidth}
        strokeDasharray={horizontalLineDashArray}
      />
    );
  }

  for (j = 0; j < columns; j++) {
    const pointY1 = j * columnHeight + y;
    for (i = 0; i < rows; i++) {
      if (hLines) {
      }

      rects.push(
        <rect
          key={i * j}
          x={x + i * rowWidth}
          y={pointY1}
          width={rowWidth}
          height={columnHeight}
          fill="none"
          strokeWidth="0"
          stroke="black"
        />
      );
    }
  }

  return (
    <g>
      <g>{hLines}</g>
      <g>{vLines}</g>
      <g>{rects}</g>
    </g>
  );
};

export default Grid;

import React from "react";
import Path from "./Path";

const scaleValue = (value, minNorm, maxNorm, minValue, maxValue) => {
  return (
    ((maxNorm - minNorm) / (maxValue - minValue)) * (value - minValue) +
    minValue
  );
};

const LineGraph = ({
  x = 0,
  y = 0,
  width = 100,
  height = 100,
  stroke = "#0000FF",
  strokeWidth = 2,
  strokeDasharray,
  filterXMin = 1,
  filterXMax = 12,
  rangeXMin = 0,
  rangeXMax = 13,
  rangeYMin = 0,
  rangeYMax = 100,

  data,
  yKey = "y",
  xKey = "x",
  tooltip
}) => {
  const points = data
    .filter(
      dataItem => dataItem[xKey] >= filterXMin && dataItem[xKey] <= filterXMax
    )
    .map((dataItem, index) => {
      let x1 = scaleValue(dataItem[xKey], 0, width, rangeXMin, rangeXMax) + x;

      let pointVert = scaleValue(
        dataItem[yKey],
        0,
        height,
        rangeYMin,
        rangeYMax - rangeYMin
      );
      let y1 = height - pointVert + y;

      return [x1, y1];
    });

  return (
    <g>
      <Path
        width={width}
        height={height}
        stroke={stroke}
        strokeWidth={strokeWidth}
        strokeDasharray={strokeDasharray}
        points={points}
        bezier={false}
      />
    </g>
  );
};

export default LineGraph;

import React, {
  useState,
  useRef,
  useEffect,
  useLayoutEffect,
  useCallback
} from "react";
import { createPortal } from "react-dom";
import clsx from "clsx";

import TooltipCallout from "./TooltipCallout";
import usePortalOverlay from "../../hooks/usePortalOverlay";
import useWindowSize from "../../hooks/useWindowSize";

const TOP = "top";
const LEFT = "left";
const BOTTOM = "bottom";
const RIGHT = "right";

const Tooltip = ({
  parent,
  position = TOP,
  active = false,
  textColor = "white",

  fontFamily = "inherit",
  lineHeight = "inherit",
  fontWeight = "inherit",
  fontStretch = "inherit",
  fontVariant = "inherit",
  fontSize = "13px",

  fade = true,
  fadeTime = 1,
  arrow = true,
  sticky = true,
  offset = 3,
  padding = "6px",
  backgroundColor = "black",
  borderRadius = 6,
  opacity = 0.85,
  timeout = 1,
  calloutWidth = 6,
  overlayHostId = "root",
  overlayId = "tooltip-overlay",
  zIndex = 1000,
  children
}) => {
  const [scrolled, setScrolled] = useState(false);

  const portalOverlay = usePortalOverlay(overlayId, overlayHostId, () =>
    setScrolled(true)
  );
  const tipElemRef = useRef();
  const [parentElemRef, setParentElemRef] = useState();
  const [visible, setVisible] = useState(false);
  const [hover, setHover] = useState(false);
  const [currentPosition, setCurrentPosition] = useState(position);

  //when the tooltip goes inactive there is a time out before it actually closes
  //so that we can show the transition effects
  const [targetTimeout, setTargetTimeout] = useState();
  const [visibleTimeout, setVisibleTimeout] = useState();
  const [positioned, setPositioned] = useState(false);

  //we change effects such as visible and hidden using classes
  const [className, setClassName] = useState();

  //tracks the window size so we can move tooltips when window is resized
  const [windowWidth, windowHeight] = useWindowSize();

  // target and visibile state management
  useEffect(() => {
    if (visible && !active && !hover) {
      if (!visibleTimeout) {
        setVisibleTimeout(
          setTimeout(() => {
            setVisible(false);
            setVisibleTimeout(undefined);
          }, timeout * 1000)
        );
      }
    }

    if (active || hover) {
      if (visibleTimeout) {
        clearTimeout(visibleTimeout);
        setVisibleTimeout(undefined);
      }

      if (targetTimeout) {
        clearTimeout(targetTimeout);
        setTargetTimeout(undefined);
      }

      if (!visible) {
        setVisible(true);
        setPositioned(false);
      }
    }

    if (
      !visible &&
      !active &&
      !hover &&
      tipElemRef.current &&
      !visibleTimeout &&
      !targetTimeout
    ) {
      setTargetTimeout(
        setTimeout(() => {
          portalOverlay.destroyTarget();
          tipElemRef.current = null;
          setTargetTimeout(undefined);
        }, (fadeTime + timeout) * 1000)
      );
    }
  }, [
    active,
    hover,
    timeout,
    portalOverlay,
    visible,
    visibleTimeout,
    targetTimeout,
    fadeTime
  ]);

  //sets up the effects that are controlled by css classes
  useEffect(() => {
    let cn = clsx(
      currentPosition,
      visible && "visible",
      fade && "fade",
      arrow && "arrow"
    );
    if (cn !== className) {
      setClassName(cn);
    }
  }, [arrow, className, currentPosition, fade, visible]);

  //memoized fuction to calculate and then set the position of the tooltip
  const setPosition = useCallback(
    tipElem => {
      const scrollY =
        window.scrollY !== undefined ? window.scrollY : window.pageYOffset;
      const scrollX =
        window.scrollX !== undefined ? window.scrollX : window.pageXOffset;
      const parent = parentElemRef.current;
      const parentRect = parent.getBoundingClientRect();
      const tipRect = tipElem.getBoundingClientRect();
      const calculatePosition = position => {
        let top = 0;
        let left = 0;
        switch (position) {
          case TOP:
            top = scrollY + parentRect.top - tipRect.height - offset;
            left =
              scrollX +
              parentRect.left +
              parentRect.width / 2 -
              tipRect.width / 2;
            break;

          case LEFT:
            top =
              scrollY +
              parentRect.top +
              parentRect.height / 2 -
              tipRect.height / 2;
            left = scrollX + parentRect.left - tipRect.width - offset;
            break;

          case BOTTOM:
            top = scrollY + parentRect.top + parentRect.height + offset;
            left =
              scrollX +
              parentRect.left +
              parentRect.width / 2 -
              tipRect.width / 2;
            break;

          case RIGHT:
            top =
              scrollY +
              parentRect.top +
              parentRect.height / 2 -
              tipRect.height / 2;
            left = scrollX + parentRect.left + parentRect.width + offset;
            break;

          default:
            break;
        }
        return [top, left];
      };

      setCurrentPosition(position);
      let [top, left] = calculatePosition(position);
      switch (position) {
        case TOP:
          if (top < 0) {
            [top, left] = calculatePosition(BOTTOM);
            setCurrentPosition(BOTTOM);
          }
          break;

        case LEFT:
          if (left < 0) {
            [top, left] = calculatePosition(RIGHT);
            setCurrentPosition(RIGHT);
          }
          break;

        case BOTTOM:
          if (
            top + tipRect.height >
            (window.innerHeight || document.documentElement.clientHeight)
          ) {
            [top, left] = calculatePosition(TOP);
            setCurrentPosition(TOP);
          }
          break;
        case RIGHT:
          if (
            left + tipRect.width >
            (window.innerWidth || document.documentElement.clientWidth)
          ) {
            [top, left] = calculatePosition(LEFT);
            setCurrentPosition(LEFT);
          }
          break;

        default:
          break;
      }

      tipElem.style.top = `${top}px`;
      tipElem.style.left = `${left}px`;
    },
    [offset, parentElemRef, position]
  );

  //changes the parentElemRef whenever the parent prop changes
  useEffect(() => {
    setParentElemRef(parent);
  }, [parent]);

  //reposition the tooltip if window resizes
  useLayoutEffect(() => {
    if (
      !tipElemRef ||
      !tipElemRef.current ||
      !parentElemRef ||
      !parentElemRef.current
    )
      return;
    setPositioned(false);
  }, [parentElemRef, windowWidth, windowHeight]);

  //set the position of the tooltip based on props
  useLayoutEffect(() => {
    if (!visible && !active && !hover && !targetTimeout) return;
    if (!tipElemRef.current) {
      const tipElem = portalOverlay.createTarget();
      Object.assign(tipElem.style, {
        zIndex: `${zIndex}`
      });

      tipElemRef.current = tipElem;
    }

    if (parentElemRef && parentElemRef.current && (!positioned || scrolled)) {
      setPosition(tipElemRef.current);
      setPositioned(true);
      setScrolled(false);
    }
  }, [
    active,
    hover,
    parentElemRef,
    portalOverlay,
    positioned,
    scrolled,
    setPosition,
    targetTimeout,
    visible,
    zIndex
  ]);

  //if tooltip target does not exist, we cannot render so return null
  if (!tipElemRef.current) return null;

  return createPortal(
    <TooltipCallout
      fontFamily={fontFamily}
      lineHeight={lineHeight}
      fontWeight={fontWeight}
      fontStretch={fontStretch}
      fontVariant={fontVariant}
      fontSize={fontSize}
      textColor={textColor}
      backgroundColor={backgroundColor}
      opacity={opacity}
      fadeTime={fadeTime}
      calloutWidth={calloutWidth}
      borderRadius={borderRadius}
      padding={padding}
      className={className}
      onMouseEnter={() => {
        if (sticky) setHover(true);
      }}
      onMouseLeave={() => {
        if (sticky) setHover(false);
      }}
    >
      {children}
    </TooltipCallout>,
    tipElemRef.current
  );
};

export default Tooltip;

import React, { useRef, useState } from "react";
import logo from "./logo.svg";
import "./App.css";
import Tooltip from "./ui/Tooltip/Tooltip";

function App() {
  const el = useRef();
  const el2 = useRef();
  const el3 = useRef();

  const [active, setActive] = useState(false);
  const [pinned, setPinned] = useState(false);

  return (
    <div
      id="App1"
      style={{ overflowY: "scroll", width: "100vw", height: "100vh" }}
      onScroll={() => console.log(Date.Now)}
    >
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <p style={{ backgroundColor: "red" }} ref={el}>
            Edit <code>src/App.js</code> and save to reload.
          </p>
          <Tooltip parent={el} active={active} position="top">
            tooltip
          </Tooltip>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
            onMouseEnter={() => {
              setActive(true);
            }}
            onMouseLeave={() => {
              setActive(false);
            }}
          >
            Learn React
          </a>
        </header>
      </div>
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <p>
            Edit <code>src/App.js</code> and save to reload.
          </p>
          <Tooltip parent={el2} active={active} position="top">
            <p>tooltip</p>
            <p>tooltip</p>
            <p>tooltip</p>
          </Tooltip>
          <Tooltip parent={el2} active={active} position="left">
            tooltip
          </Tooltip>
          <Tooltip parent={el2} active={active} position="bottom">
            tooltip
          </Tooltip>
          <Tooltip parent={el2} active={active} position="right">
            tooltip
          </Tooltip>
          <a
            ref={el2}
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
            onMouseEnter={() => {
              if (!active) setActive(true);
            }}
            onMouseLeave={() => {
              if (active) setActive(false);
            }}
          >
            Learn React
          </a>
        </header>
      </div>
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <p ref={el3}>
            Edit <code>src/App.js</code> and save to reload.
          </p>
          <Tooltip parent={el3} active={active} position="top">
            tooltip
          </Tooltip>
          <Tooltip parent={el3} active={active} position="left">
            tooltip
          </Tooltip>
          <Tooltip parent={el3} active={active} position="bottom">
            tooltip
          </Tooltip>
          <Tooltip parent={el3} active={active} position="right">
            tooltip
          </Tooltip>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
            onMouseEnter={() => {
              setActive(true);
            }}
            onMouseLeave={() => {
              setActive(false);
            }}
          >
            Learn React
          </a>
        </header>
      </div>
    </div>
  );
}

export default App;

import { useRef, useState } from "react";

const usePortalOverlay = (
  overlayId = "overlay",
  hostId = "root",
  onScroll = null
) => {
  const overlayElemRef = useRef(null);
  const portalTargetElemRef = useRef(null);
  const [scroll, setScroll] = useState();
  const [created, setCreated] = useState(false);

  const onScrollHandler = () => {
    let elem = overlayElemRef.current.firstElementChild;
    while (elem) {
      let event = new Event("bubble_scroll");
      elem.dispatchEvent(event);
      elem = elem.nextElementSibling;
    }
  };

  //creates the element that will host our portals
  const createOverlayElement = id => {
    const overlayElem = document.createElement("div");
    overlayElem.setAttribute("id", id);
    return overlayElem;
  };

  //adds the overlay element to the host
  const addOverlayElement = (overlayElem, host) => {
    host.insertBefore(overlayElem, host.firstElementChild);
    if (onScroll) {
      //we need to listen if any of the ancestors have scrolled
      //so we can call the onScrolled method passed in the prop
      let elem = host;
      while (elem) {
        elem.addEventListener("scroll", onScrollHandler, true);
        elem = elem.parentElement;
      }
    }
  };

  //creates a target for a create portal call
  const createTarget = () => {
    if (created) return portalTargetElemRef.current;
    setCreated(true);

    let host;
    if (hostId) {
      host = document.querySelector(`#${hostId}`);
    } else {
      host = document.body;
    }

    // Look for the targeted element overlay in the dom to append to
    const existingOverlay = host.querySelector(`#${overlayId}`);
    // or create it if it doesn't exist.
    const overlayElem = existingOverlay || createOverlayElement(overlayId);
    if (!existingOverlay) {
      addOverlayElement(overlayElem, host, onScrollHandler);
    }
    overlayElemRef.current = overlayElem;

    if (!portalTargetElemRef.current) {
      portalTargetElemRef.current = document.createElement("div");
      Object.assign(portalTargetElemRef.current.style, {
        position: "absolute"
      });

      if (onScroll) {
        setScroll(true);

        portalTargetElemRef.current.addEventListener(
          "bubble_scroll",
          onScroll,
          true
        );
      }
    }
    overlayElem.appendChild(portalTargetElemRef.current);

    return portalTargetElemRef.current;
  };

  //function that removes the portal target from the overlay
  //it will destroy the overlay element if it contains no targets
  const destroyTarget = () => {
    if (!created) return;
    portalTargetElemRef.current.remove();
    if (
      overlayElemRef.current &&
      overlayElemRef.current.childNodes.length === 0
    ) {
      if (scroll) {
        let elem = overlayElemRef.current.parentElement;
        while (elem) {
          elem.removeEventListener("scroll", onScrollHandler);
          elem = elem.parentElement;
        }
        setScroll(false);
      }
      overlayElemRef.current.remove();
    }
    setCreated(false);
  };

  return { createTarget, destroyTarget };
};

export default usePortalOverlay;

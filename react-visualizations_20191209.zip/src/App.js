import React from "react";
import "./App.css";
import LineGraph from "./components/Visualizations/LineGraph/LineGraph";
import BarGraph from "./components/Visualizations/BarGraph/BarGraph";
import Pie from "./components/Visualizations/PieChart/Pie";
import XAxis from "./components/Visualizations/Axis/XAxis";
import YAxis from "./components/Visualizations/Axis/YAxis";
import Grid from "./components/Visualizations/Grid/Grid";
const data = [
  { x: 0, y: 65, color: "#FF00FF", label: "Dec" },
  { x: 1, y: 2, color: "#FF00FF", label: "Jan" },
  { x: 2, y: 47, label: "Feb" },
  { x: 3, y: 55, label: "Mar" },
  { x: 4, y: 42, label: "Apr" },
  { x: 5, y: 65, label: "May" },
  { x: 6, y: 55, label: "Jun" },
  { x: 7, y: 62, label: "Jul" },
  { x: 8, y: 82, label: "Aug" },
  { x: 9, y: 75, label: "Sep" },
  { x: 10, y: 53, label: "Oct" },
  { x: 11, y: 1, label: "Nov" },
  { x: 12, y: 100, label: "Dec" },
  { x: 13, y: 87, label: "Jan" }
];

const yAxisTicks = [
  { y: 25, label: "25 Million" },
  { y: 50, label: "50 Million" },
  { y: 75, label: "75 Million" },
  { y: 100, label: "100 Million" }
];
const pieData = [
  { category: "A", percentage: 70 },
  { category: "B", percentage: 120 },
  { category: "C", percentage: 380 },
  { category: "D", percentage: 480 }
];

function App() {
  return (
    <div id="App" style={{ margin: "10px" }}>
      <div id="App" style={{ margin: "10px" }}>
        <svg width={450} height={300}>
          <Grid
            x={50}
            y={10}
            width={400}
            height={200}
            rows={13}
            columns={4}
            data={data}
          />
          <YAxis x={50} y={10} height={200} rangeMax={100} data={yAxisTicks} />
          <XAxis x={50} y={210} width={400} data={data} />

          <BarGraph
            x={50}
            y={10}
            width={400}
            height={200}
            scaleYMin={0}
            scaleYMax={100}
            scaleXMin={0}
            scaleXMax={13}
            defaultColor={"red"}
            tooltip="hello"
            data={data}
          />
          <LineGraph
            x={50}
            y={10}
            width={400}
            height={200}
            scaleYMax={100}
            scaleXMin={0}
            scaleXMax={12}
            defaultColor={"red"}
            tooltip="line"
            data={data}
          />
        </svg>
      </div>
      <div id="App" style={{ margin: "10px" }}>
        <svg width={240} height={200}>
          <LineGraph
            x={0}
            y={0}
            width={240}
            height={200}
            scaleYMax={100}
            scaleXMin={1}
            scaleXMax={12}
            defaultColor={"red"}
            tooltip="line"
            data={data}
          />
        </svg>
      </div>
      <div id="App" style={{ margin: "10px" }}>
        <svg width={240} height={200}>
          <BarGraph
            x={0}
            y={0}
            width={240}
            height={200}
            scaleYMax={100}
            scaleXMin={1}
            scaleXMax={12}
            defaultColor={"red"}
            data={data}
            tooltip="bar"
          />
          <LineGraph
            x={0}
            y={0}
            width={240}
            height={200}
            scaleYMax={100}
            scaleXMin={1}
            scaleXMax={12}
            defaultColor={"red"}
            data={data}
            tooltip="line"
          />
        </svg>
      </div>
      <div id="App" style={{ margin: "10px" }}>
        <svg width={200} height={200}>
          <Pie data={pieData} size={200} />
        </svg>
      </div>
      <div id="App" style={{ margin: "10px" }}>
        <svg width={300} height={200}>
          <Grid x={0} width={300} height={200} rangeXMax={100} data={data} />
        </svg>
      </div>
    </div>
  );
}

export default App;

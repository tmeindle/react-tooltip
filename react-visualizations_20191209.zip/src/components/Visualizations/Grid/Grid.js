import React from "react";

const scaleValue = (value, minNorm, maxNorm, minValue, maxValue) => {
  return (
    ((maxNorm - minNorm) / (maxValue - minValue)) * (value - minValue) +
    minValue
  );
};

const Grid = ({
  x = 0,
  y = 0,
  rows = 10,
  columns = 10,
  width = 100,
  height = 100,
  barWidth = 5,
  data,
  yKey = "y",
  scaleYMin = 0,
  scaleYMax = 100,
  xKey = "x",
  scaleXMin = 0,
  scaleXMax = 12,
  colorKey = "color",
  defaultColor = "#FF00FF",
  //verticalLines = true,
  //horizontalLines = true,
  tooltip
}) => {
  let rects = [];
  let verticalLines = [];
  let horizontalLines = [];

  let i, j;
  let rowWidth = width / rows;
  let columnHeight = height / columns;

  if (verticalLines) {
    for (j = 0; j < rows + 1; j++) {
      verticalLines.push(
        <line
          x1={x + j * rowWidth}
          y1={y}
          x2={x + j * rowWidth}
          y2={y + height}
          stroke="black"
          strokeWidth="1"
        />
      );
    }
  }

  if (horizontalLines) {
    for (j = 0; j < columns; j++) {
      horizontalLines.push(
        <line
          x1={x}
          y1={y + j * columnHeight}
          x2={x + width}
          y2={y + j * columnHeight}
          stroke="black"
          strokeWidth="1"
          strokeDasharray="3,6"
        />
      );
    }
  }

  for (j = 0; j < columns; j++) {
    const pointY1 = j * columnHeight + y;
    for (i = 0; i < rows; i++) {
      if (horizontalLines) {
      }

      rects.push(
        <rect
          key={i * j}
          x={x + i * rowWidth}
          y={pointY1}
          width={rowWidth}
          height={columnHeight}
          fill="none"
          strokeWidth="0"
          stroke="black"
        />
      );
    }
  }

  /*
    let barHoriz =
      scaleValue(dataItem[xKey], 0, width, scaleXMin, scaleXMax) + x;
    let x1 = barHoriz - barWidth / 2;

    let barHeight = scaleValue(
      dataItem[yKey],
      0,
      height,
      scaleYMin,
      scaleYMax - scaleYMin
    );
    let y1 = height - barHeight + y;

    return [
      x1,
      y1,
      barWidth,
      barHeight,
      dataItem[colorKey] ? dataItem[colorKey] : defaultColor
    ];
  });

  return <Bars bars={bars} tooltip={tooltip} />;
  */
  return (
    <g>
      <g>{horizontalLines}</g>
      <g>{verticalLines}</g>
      <g>{rects}</g>
    </g>
  );
};

export default Grid;

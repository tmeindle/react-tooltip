import React, { useRef } from "react";
import Tooltip from "../Tooltip/Tooltip";

import pathString from "../svgHelpers/pathString";

const Path = ({
  stroke = "#0000FF",
  strokeWidth = 1,
  strokeDasharray,
  points,
  tooltip,
  bezier = false,
  tooltipProps = {},
  alignmentBaseline = "auto"
}) => {
  const pathRef = useRef();
  return (
    <>
      <path
        key="path"
        ref={pathRef}
        d={pathString(points, bezier)}
        fill="none"
        strokeWidth={strokeWidth}
        stroke={stroke}
        strokeDasharray={strokeDasharray}
      />
      {tooltip ? (
        <Tooltip key="tooltip" {...tooltipProps}>
          {tooltip}
        </Tooltip>
      ) : null}
    </>
  );
};

export default Path;

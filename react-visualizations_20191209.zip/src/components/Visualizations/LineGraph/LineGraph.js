import React from "react";
import Point from "./Point";
import Path from "./Path";

const scaleValue = (value, minNorm, maxNorm, minValue, maxValue) => {
  return (
    ((maxNorm - minNorm) / (maxValue - minValue)) * (value - minValue) +
    minValue
  );
};

const LineGraph = ({
  x = 0,
  y = 0,
  width = 100,
  height = 100,
  stroke = "#0000FF",
  strokeWidth = 2,
  strokeDasharray,
  yKey = "y",
  scaleYMin = 0,
  scaleYMax = 100,
  xKey = "x",
  scaleXMin = 0,
  scaleXMax = 100,
  data,
  showPoints = false,
  pointSize = 3,
  pointColor = "#FF0000",
  tooltip
}) => {
  const scaleX = scaleXMin + (scaleXMax - scaleXMin) + 1;

  const points = data.reduce((array, dataItem) => {
    let x1 = scaleValue(dataItem[xKey], 0, width, scaleXMin, scaleX) + x;
    let pointHeight = scaleValue(
      dataItem[yKey],
      0,
      height,
      scaleYMin,
      scaleYMax - scaleYMin
    );
    let y1 = height - pointHeight + y;
    array.push([x1, y1]);
    return array;
  }, []);
  return (
    <g>
      <Path
        width={width}
        height={height}
        stroke={stroke}
        strokeWidth={strokeWidth}
        strokeDasharray={strokeDasharray}
        points={points}
        bezier={true}
      />

      {points.map(([x1, y1], index) => {
        return (
          <Point
            key={`point` + index}
            x={x1}
            y={y1}
            size={pointSize}
            fill={showPoints ? pointColor : "transparent"}
            stroke={"none"}
            strokeWidth={0}
            tooltip={tooltip}
            pointColor={pointColor}
          />
        );
      })}
    </g>
  );
};

export default LineGraph;

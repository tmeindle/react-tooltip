const indexOf = child => {
  let index = 0;
  while ((child = child.previousSibling) !== null) index++;
  return index;
};

export default indexOf;

const scaleValueLinear = (value, minNorm, maxNorm, minValue, maxValue) => {
  return (
    ((maxNorm - minNorm) / (maxValue - minValue)) * (value - minValue) +
    minValue
  );
};

export default scaleValueLinear;

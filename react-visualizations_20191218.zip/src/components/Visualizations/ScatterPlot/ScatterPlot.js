import React, { useState } from "react";
import Point from "../components/Point";
import Polygon from "../components/Polygon";
import scaleValue from "../helpers/scaleLinear";
import indexOf from "../helpers/indexOf";

const ScatterPlot = ({
  x = 0,
  y = 0,
  width = 100,
  height = 100,
  pointSize = 5,
  defaultColor = "#FF00FF",

  data,
  xKey = "x",
  xMin = 0,
  xMax = 13,
  filterXMin = 1,
  filterXMax = 12,
  yKey = "y",
  yMin = 0,
  yMax = 100,
  colorKey = "color",

  tooltipKey = "tooltip",
  tooltipStyle = { backgroundColor: "black", position: "top" },

  onMouseEnter,
  onMouseLeave,
  onMouseOver,
  onMouseOut
}) => {
  const [hoverIndex, setHoverIndex] = useState();
  const handleMouseEnter = e => {
    const pointIndex = indexOf(e.currentTarget);
    setHoverIndex(pointIndex);
    onMouseEnter && onMouseEnter(e, pointIndex);
  };

  const handleMouseLeave = e => {
    setHoverIndex();
    onMouseLeave && onMouseLeave(e, indexOf(e.currentTarget));
  };

  const points = data
    .filter(
      dataItem =>
        (filterXMin === undefined || dataItem[xKey] >= filterXMin) &&
        (filterXMax === undefined || dataItem[xKey] <= filterXMax)
    )
    .map((dataItem, index) => {
      let pointHoriz = scaleValue(dataItem[xKey], 0, width, xMin, xMax) + x;
      let x1 = pointHoriz;

      let pointVert = scaleValue(dataItem[yKey], 0, height, yMin, yMax - yMin);
      let y1 = height - pointVert + y;

      return (
        <Polygon
          key={index}
          x={x1}
          y={y1}
          size={pointSize}
          fill={dataItem[colorKey] ? dataItem[colorKey] : defaultColor}
          tooltip={dataItem[tooltipKey]}
          tooltipActive={index === hoverIndex}
          tooltipStyle={tooltipStyle}
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
          onMouseOver={onMouseOver}
          onMouseOut={onMouseOut}
        />
      );
    });

  return <g>{points}</g>;
};

export default ScatterPlot;

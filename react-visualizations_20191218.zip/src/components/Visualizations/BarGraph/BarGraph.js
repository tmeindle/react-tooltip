import React, { useState } from "react";
import Bar from "../components/Bar";
import scaleValue from "../helpers/scaleLinear";
import indexOf from "../helpers/indexOf";

export const BarGraph = ({
  x = 0,
  y = 0,
  width = 100,
  height = 100,
  barWidth = 5,

  data,
  xKey = "x",
  xMin = 0,
  xMax = 13,
  filterXMin = 1,
  filterXMax = 12,
  yKey = "y",
  yMin = 0,
  yMax = 100,

  defaultColor = "#FF00FF",
  colorKey = "color",

  tooltipKey = "tooltip",
  tooltipStyle = { backgroundColor: "black", position: "top" },

  onMouseEnter,
  onMouseLeave,
  onMouseOver,
  onMouseOut
}) => {
  const [hoverIndex, setHoverIndex] = useState();
  const handleMouseEnter = e => {
    const barIndex = indexOf(e.currentTarget);
    setHoverIndex(barIndex);
    onMouseEnter && onMouseEnter(e, barIndex);
  };

  const handleMouseLeave = e => {
    setHoverIndex();
    onMouseLeave && onMouseEnter(e, indexOf(e.currentTarget));
  };

  const bars = data
    .filter(
      dataItem =>
        (filterXMin === undefined || dataItem[xKey] >= filterXMin) &&
        (filterXMax === undefined || dataItem[xKey] <= filterXMax)
    )
    .map((dataItem, index) => {
      let barHoriz = scaleValue(dataItem[xKey], 0, width, xMin, xMax) + x;
      let x1 = barHoriz - barWidth / 2;

      let barHeight = scaleValue(dataItem[yKey], 0, height, yMin, yMax - yMin);
      let y1 = height - barHeight + y;

      return (
        <Bar
          key={index}
          x={x1}
          y={y1}
          width={barWidth}
          height={barHeight}
          fill={dataItem[colorKey] ? dataItem[colorKey] : defaultColor}
          tooltip={dataItem[tooltipKey]}
          tooltipActive={index === hoverIndex}
          tooltipStyle={tooltipStyle}
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
          onMouseOver={onMouseOver}
          onMouseOut={onMouseOut}
        />
      );
    });

  return <g>{bars}</g>;
};

export default BarGraph;

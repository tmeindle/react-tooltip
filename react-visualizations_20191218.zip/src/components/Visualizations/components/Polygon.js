import React, { useRef } from "react";
import Tooltip from "../Tooltip/Tooltip";
import polygonString from "../helpers/polygonString";
const Polygon = ({
  x,
  y,
  stroke = "black",
  strokeWidth = 1,
  fill = "red",
  size = 5,
  sides = 5,
  strokeOpacity = 1,

  tooltip,
  tooltipActive = false,
  tooltipStyle = { position: "top" },

  onMouseEnter,
  onMouseLeave,
  onMouseOver,
  onMouseOut
}) => {
  const polygonRef = useRef();
  return (
    <>
      <path
        key="polygon"
        ref={polygonRef}
        d={polygonString(sides, size, x, y)}
        stroke={stroke}
        strokeWidth={strokeWidth}
        strokeOpacity={strokeOpacity}
        fill={fill}
        onMouseEnter={onMouseEnter}
        onMouseLeave={onMouseLeave}
        onMouseOver={onMouseOver}
        onMouseOut={onMouseOut}
      />
      <Tooltip
        key="tooltip"
        parent={polygonRef}
        active={tooltipActive}
        {...tooltipStyle}
      >
        {tooltip}
      </Tooltip>
    </>
  );
};

export default Polygon;

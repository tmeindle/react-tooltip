import React, { useRef } from "react";
import Tooltip from "../Tooltip/Tooltip";
import arcString from "../helpers/arcString";
const Arc = ({
  startAngle,
  endAngle,
  outerRadius,
  innerRadius,
  stroke,
  strokeWidth,
  strokeOpacity,
  fill,

  tooltip,
  tooltipActive = false,
  tooltipStyle = { position: "top" },

  onMouseEnter,
  onMouseLeave,
  onMouseOver,
  onMouseOut
}) => {
  const arcRef = useRef();
  return (
    <>
      <path
        ref={arcRef}
        key="arc"
        d={arcString(
          startAngle,
          endAngle,
          outerRadius,
          innerRadius,
          strokeWidth
        )}
        stroke={stroke}
        strokeWidth={strokeWidth}
        strokeOpacity={strokeOpacity}
        fill={fill}
        onMouseEnter={onMouseEnter}
        onMouseLeave={onMouseLeave}
        onMouseOver={onMouseOver}
        onMouseOut={onMouseOut}
      />
      <Tooltip
        key="tooltip"
        parent={arcRef}
        active={tooltipActive}
        {...tooltipStyle}
      >
        {tooltip}
      </Tooltip>
    </>
  );
};

export default Arc;

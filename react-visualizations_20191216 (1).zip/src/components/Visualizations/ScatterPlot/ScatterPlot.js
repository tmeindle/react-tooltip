import React from "react";
import Point from "../components/Point";
import scaleValue from "../helpers/scaleLinear";

const ScatterPlot = ({
  x = 0,
  y = 0,
  width = 100,
  height = 100,
  pointSize = 5,
  defaultColor = "#FF00FF",

  data,
  xKey = "x",
  xMin = 0,
  xMax = 13,
  filterXMin = 1,
  filterXMax = 12,
  yKey = "y",
  yMin = 0,
  yMax = 100,
  colorKey = "color",

  tooltip
}) => {
  const points = data
    .filter(
      dataItem =>
        (filterXMin === undefined || dataItem[xKey] >= filterXMin) &&
        (filterXMax === undefined || dataItem[xKey] <= filterXMax)
    )
    .map((dataItem, index) => {
      let pointHoriz = scaleValue(dataItem[xKey], 0, width, xMin, xMax) + x;
      let x1 = pointHoriz;

      let pointVert = scaleValue(dataItem[yKey], 0, height, yMin, yMax - yMin);
      let y1 = height - pointVert + y;

      return [x1, y1, dataItem[colorKey] ? dataItem[colorKey] : defaultColor];
    });

  return (
    <g>
      {points.map(([x1, y1], index) => (
        <Point key={index} size={pointSize} x={x1} y={y1} />
      ))}
    </g>
  );
};

export default ScatterPlot;

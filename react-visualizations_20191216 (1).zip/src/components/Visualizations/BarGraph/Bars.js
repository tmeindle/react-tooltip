import React from "react";
import Bar from "../components/Bar";

const Bars = ({ bars, tooltip }) => {
  return (
    <g>
      {bars.map((bar, index) => {
        return (
          <Bar
            key={index}
            x={bar[0]}
            y={bar[1]}
            width={bar[2]}
            height={bar[3]}
            fill={bar[4]}
            tooltip={tooltip}
          />
        );
      })}
    </g>
  );
};

export default Bars;

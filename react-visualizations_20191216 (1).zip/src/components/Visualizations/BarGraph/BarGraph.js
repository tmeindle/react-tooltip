import React from "react";
import Bars from "./Bars";
import scaleValue from "../helpers/scaleLinear";

export const BarGraph = ({
  x = 0,
  y = 0,
  width = 100,
  height = 100,
  barWidth = 5,
  defaultColor = "#FF00FF",

  data,
  xKey = "x",
  xMin = 0,
  xMax = 13,
  filterXMin = 1,
  filterXMax = 12,
  yKey = "y",
  yMin = 0,
  yMax = 100,
  colorKey = "color",

  tooltip
}) => {
  const bars = data
    .filter(
      dataItem =>
        (filterXMin === undefined || dataItem[xKey] >= filterXMin) &&
        (filterXMax === undefined || dataItem[xKey] <= filterXMax)
    )
    .map((dataItem, index) => {
      let barHoriz = scaleValue(dataItem[xKey], 0, width, xMin, xMax) + x;
      let x1 = barHoriz - barWidth / 2;

      let barHeight = scaleValue(dataItem[yKey], 0, height, yMin, yMax - yMin);
      let y1 = height - barHeight + y;

      return [
        x1,
        y1,
        barWidth,
        barHeight,
        dataItem[colorKey] ? dataItem[colorKey] : defaultColor
      ];
    });

  return <Bars bars={bars} tooltip={tooltip} />;
};

export default BarGraph;

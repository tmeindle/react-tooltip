import React from "react";
import Path from "../components/Path";
import scaleValue from "../helpers/scaleLinear";

const XAxisLabels = ({
  x = 0,
  y = 0,
  width = 100,
  alignmentBaseline = "text-before-edge",
  textAnchor = "middle",
  textRotation = 0,
  textStrokeWidth = 1,
  textStroke = "black",
  fontSize = 11,

  data,
  labelKey = "label",
  xKey = "x",
  xMin = 0,
  xMax = 13,
  filterXMin = 1,
  filterXMax = 12,
  colorKey = "color",

  tooltip
}) => {
  if (!data) return null;
  const labels = data
    .filter(
      dataItem =>
        (filterXMin === undefined || dataItem[xKey] >= filterXMin) &&
        (filterXMax === undefined || dataItem[xKey] <= filterXMax)
    )
    .map((dataItem, index) => {
      let textHoriz = scaleValue(dataItem[xKey], 0, width, xMin, xMax);
      let x1 = textHoriz + x;

      let textStyle = {
        alignmentBaseline: alignmentBaseline,
        textAnchor: textAnchor,
        strokeWidth: textStrokeWidth,
        stroke: textStroke,
        fontSize: fontSize
      };
      if (textRotation)
        textStyle.transform = `rotate(${textRotation}, ${x1}, ${y})`;
      return (
        <text key={index} x={x1} y={y} style={textStyle}>
          {dataItem[labelKey]}
        </text>
      );
    });
  return labels;
};

const XAxis = props => {
  let { x = 0, y = 0, width = 100 } = props;

  const axis = (
    <Path
      points={[
        [x, y],
        [x + width, y]
      ]}
    />
  );

  return (
    <g>
      {axis}
      <XAxisLabels {...props} />
    </g>
  );
};

export default XAxis;

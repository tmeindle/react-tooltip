import React from "react";
import styled from "styled-components";

const TooltipCalloutStyle = styled.div`
  background-color: ${props => props.backgroundColor};
  color: ${props => props.textColor};
  padding: ${props => props.padding};
  border-radius: ${props => props.borderRadius}px;
  font-family: ${props => props.fontFamily};
  line-height: ${props => props.lineHeight};
  font-weight: ${props => props.fontWeight};
  font-stretch: ${props => props.fontStretch};
  font-variant: ${props => props.fontVariant};
  font-size: ${props => props.fontSize};
  border-width: ${props => props.borderWidth}px;
  border-style: solid;
  border-color: ${props => props.borderColor};

  &.fade {
    opacity: 0;
    transition: opacity ${props => props.fadeTime}s ease-in-out 0s,
      visibility ${props => props.fadeTime}s ease-in-out 0s;
    &.visible {
      opacity: ${props => props.opacityValue};
    }
  }

  &.visible {
    visibility: visible;
  }
  &:not(.visible) {
    visibility: hidden;
  }

  &.arrow {
    &::before {
      content: "";
      pointer-events: none;
      position: absolute;
      border-width: ${props => props.calloutWidth}px;
      border-style: solid;
      border-color: transparent;
    }
    &::after {
      content: "";
      pointer-events: none;
      position: absolute;
      border-width: ${props => props.calloutWidth}px;
      border-style: solid;
      border-color: transparent;
    }
  }

  &.bottom.arrow {
    margin-top: ${props => props.calloutWidth}px;

    &::before {
      top: 0px;
      left: 50%;
      margin-left: -${props => props.calloutWidth}px;
      margin-top: -${props => props.calloutWidth}px;
      border-bottom-color: ${props => props.borderColor};
    }

    &::after {
      border-width: ${props => props.calloutWidth}px;
      top: 0%;
      left: 50%;
      margin-left: -${props => props.calloutWidth}px;
      margin-top: -${props => props.calloutWidth - props.borderWidth - 0.5}px;
      border-bottom-color: ${props => props.backgroundColor};
    }
  }

  &.left.arrow {
    margin-right: ${props => props.calloutWidth}px;
    &::before {
      top: 50%;
      right: 0%;
      margin-top: -${props => props.calloutWidth}px;
      margin-right: -${props => props.calloutWidth}px;
      border-left-color: ${props => props.backgroundColor};
    }

    &::after {
      border-width: ${props => props.calloutWidth}px;
      top: 50%;
      right: 0%;
      margin-top: -${props => props.calloutWidth}px;
      margin-right: -${props => props.calloutWidth - props.borderWidth - 0.5}px;
      border-left-color: ${props => props.backgroundColor};
    }
  }

  &.top.arrow {
    margin-bottom: ${props => props.calloutWidth}px;
    &::before {
      bottom: 0%;
      left: 50%;
      margin-left: -${props => props.calloutWidth}px;
      margin-bottom: -${props => props.calloutWidth}px;
      border-top-color: ${props => props.borderColor};
    }

    &::after {
      border-width: ${props => props.calloutWidth}px;
      bottom: 0%;
      left: 50%;
      margin-left: -${props => props.calloutWidth}px;
      margin-bottom: -${props => props.calloutWidth - props.borderWidth - 0.5}px;
      border-top-color: ${props => props.backgroundColor};
    }
  }

  &.right.arrow {
    margin-left: ${props => props.calloutWidth}px;
    &::before {
      top: 50%;
      left: 0%;
      margin-top: -${props => props.calloutWidth}px;
      margin-left: -${props => props.calloutWidth}px;
      border-right-color: ${props => props.borderColor};
    }

    &::after {
      left: 0%;
      top: 50%;
      margin-top: -${props => props.calloutWidth}px;
      margin-left: -${props => props.calloutWidth - props.borderWidth - 0.5}px;
      border-right-color: ${props => props.backgroundColor};
    }
  }
`;

//the only purpose this serves is to stop passing opacity to the styled component
//which makes it an attribute on the callout div in the DOM
const TooltipCallout = ({ opacity, children, ...props }) => {
  return (
    <TooltipCalloutStyle opacityValue={opacity} {...props}>
      {children}
    </TooltipCalloutStyle>
  );
};

export default TooltipCallout;

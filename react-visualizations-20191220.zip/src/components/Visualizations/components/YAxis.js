import React from "react";
import LinePath from "./LinePath";
import scaleLinear from "../helpers/scaleLinear";

const YAxisLabels = ({
  x = 0,
  y = 0,
  height = 100,

  alignmentBaseline = "bottom",
  textAnchor = "end",
  textRotation = 0,
  textStrokeWidth = 1,
  textStroke = "black",
  fontSize = 11,

  data,
  labelKey = "label",
  yKey = "y",
  yMin = 0,
  yMax = 100,
  filterYMin = 0,
  filterYMax = 100,
  colorKey = "color"
}) => {
  if (!data) return null;
  const scaleYValue = scaleLinear(0, height, yMin, yMax - yMin);
  const labels = data
    .filter(
      dataItem =>
        (filterYMin === undefined || dataItem[yKey] >= filterYMin) &&
        (filterYMax === undefined || dataItem[yKey] <= filterYMax)
    )

    .map((dataItem, index) => {
      let y1 = height - scaleYValue(dataItem[yKey]);

      let textStyle = {
        alignmentBaseline: alignmentBaseline,
        textAnchor: textAnchor,
        strokeWidth: textStrokeWidth,
        stroke: textStroke,
        fontSize: fontSize
      };

      if (textRotation)
        textStyle.transform = `rotate(${textRotation}, ${y1}, ${y})`;
      return (
        <text key={index} x={x} y={y + y1} style={textStyle}>
          {dataItem[labelKey]}
        </text>
      );
    });
  return labels;
};

const YAxis = props => {
  let { x = 0, y = 0, height = 100 } = props;

  const axis = (
    <LinePath
      points={[
        [x, y],
        [x, y + height]
      ]}
    />
  );

  return (
    <g>
      <g>
        <YAxisLabels {...props} />
      </g>
      <g>{axis}</g>
    </g>
  );
};

export default YAxis;

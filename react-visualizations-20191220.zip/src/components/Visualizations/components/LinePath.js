import React, { useRef } from "react";
import Tooltip from "../Tooltip/Tooltip";

import linePath from "../helpers/linePath";

const LinePath = ({
  stroke = "#0000FF",
  strokeWidth = 1,
  strokeDasharray,
  points,
  bezier = false,
  alignmentBaseline = "auto",

  tooltip,
  tooltipActive = false,
  tooltipStyle = { position: "top" },

  onMouseEnter,
  onMouseLeave,
  onMouseOver,
  onMouseOut
}) => {
  const pathRef = useRef();
  return (
    <>
      <path
        key="path"
        ref={pathRef}
        d={linePath(points, bezier)}
        alignmentBaseline={alignmentBaseline}
        fill="none"
        strokeWidth={strokeWidth}
        stroke={stroke}
        strokeDasharray={strokeDasharray}
        onMouseEnter={onMouseEnter}
        onMouseLeave={onMouseLeave}
        onMouseOver={onMouseOver}
        onMouseOut={onMouseOut}
      />
      <Tooltip
        key="tooltip"
        parent={pathRef}
        active={tooltipActive}
        {...tooltipStyle}
      >
        {tooltip}
      </Tooltip>
    </>
  );
};

export default LinePath;

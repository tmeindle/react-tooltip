import React, { useState } from "react";
import Point from "./Point";
import Polygon from "./Polygon";
import scaleLinear from "../helpers/scaleLinear";
import indexOf from "../helpers/indexOf";

const ScatterPlot = ({
  x = 0,
  y = 0,
  width = 100,
  height = 100,
  pointSize = 5,
  pointBorderWidth = 1,
  pointBorderColor = "black",
  shape = "triangle",
  defaultColor = "#0000FF",

  data,
  xKey = "x",
  xMin = 0,
  xMax = 13,
  filterXMin = 1,
  filterXMax = 12,
  yKey = "y",
  yMin = 0,
  yMax = 100,

  colorKey = "color",
  shapeKey = "shape",
  sizeKey = "size",
  borderColorKey = "borderColor",
  borderWidthKey = "borderWidth",
  tooltipKey = "tooltip",
  tooltipStyle = {},

  onMouseEnter,
  onMouseLeave,
  onMouseOver,
  onMouseOut
}) => {
  const [hoverIndex, setHoverIndex] = useState();
  const handleMouseEnter = e => {
    const pointIndex = indexOf(e.currentTarget);
    setHoverIndex(pointIndex);
    onMouseEnter && onMouseEnter(e, pointIndex);
  };

  const handleMouseLeave = e => {
    setHoverIndex();
    onMouseLeave && onMouseLeave(e, indexOf(e.currentTarget));
  };
  const scaleXValue = scaleLinear(0, width, xMin, xMax);
  const scaleYValue = scaleLinear(0, height, yMin, yMax - yMin);
  const points = data
    .filter(
      dataItem =>
        (filterXMin === undefined || dataItem[xKey] >= filterXMin) &&
        (filterXMax === undefined || dataItem[xKey] <= filterXMax)
    )
    .map((dataItem, index) => {
      let pointHoriz = scaleXValue(dataItem[xKey]) + x;
      let x1 = pointHoriz;

      let pointVert = scaleYValue(dataItem[yKey]);
      let y1 = height - pointVert + y;

      let pointProps = {
        key: index,
        x: x1,
        y: y1,
        size: dataItem[sizeKey] ? dataItem[sizeKey] : pointSize,
        fill: dataItem[colorKey] ? dataItem[colorKey] : defaultColor,
        stroke: dataItem[borderColorKey]
          ? dataItem[borderColorKey]
          : pointBorderColor,
        strokeWidth: dataItem[borderWidthKey]
          ? dataItem[borderWidthKey]
          : pointBorderWidth,

        tooltip: dataItem[tooltipKey],
        tooltipActive: index === hoverIndex,
        tooltipStyle: tooltipStyle,
        onMouseEnter: handleMouseEnter,
        onMouseLeave: handleMouseLeave,
        onMouseOver: onMouseOver,
        onMouseOut: onMouseOut
      };

      let point;
      switch (dataItem[shapeKey] ? dataItem[shapeKey] : shape) {
        case "octagon":
          point = <Polygon sides={8} rotation={0} {...pointProps} />;
          break;
        case "hexagon":
          point = <Polygon sides={6} rotation={0} {...pointProps} />;
          break;
        case "pentagon":
          point = <Polygon sides={5} rotation={0} {...pointProps} />;
          break;
        case "square":
          point = <Polygon sides={4} rotation={45} {...pointProps} />;
          break;
        case "triangle":
          point = <Polygon sides={3} rotation={135} {...pointProps} />;
          break;
        case "point":
        case "circle":
        default:
          point = <Point {...pointProps} />;
          break;
      }
      return point;
    });

  return <g>{points}</g>;
};

export default ScatterPlot;

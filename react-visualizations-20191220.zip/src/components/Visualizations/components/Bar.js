import React, { useRef } from "react";
import Tooltip from "../Tooltip/Tooltip";

const Bar = ({
  x,
  y,
  height,
  width,
  fill = "black",
  stroke = "black",
  strokeWidth = 1,

  tooltip,
  tooltipActive = false,
  tooltipStyle = {},

  onMouseEnter,
  onMouseLeave,
  onMouseOver,
  onMouseOut
}) => {
  const barRef = useRef();
  return (
    <>
      <rect
        key={"rect"}
        ref={barRef}
        x={x}
        y={y + strokeWidth / 2}
        width={width}
        height={height - strokeWidth - 0.5}
        stroke={stroke}
        strokeWidth={strokeWidth}
        fill={fill}
        onMouseEnter={onMouseEnter}
        onMouseLeave={onMouseLeave}
        onMouseOver={onMouseOver}
        onMouseOut={onMouseOut}
      />
      <Tooltip
        key="tooltip"
        parent={barRef}
        active={tooltipActive}
        {...tooltipStyle}
      >
        {tooltip}
      </Tooltip>
    </>
  );
};

export default Bar;

import React, { useRef } from "react";
import Tooltip from "../Tooltip/Tooltip";

const Point = ({
  x,
  y,
  stroke = "black",
  strokeWidth = 1,
  fill = "red",
  size = 15,

  tooltip,
  tooltipActive = false,
  tooltipStyle = {},

  onMouseEnter,
  onMouseLeave,
  onMouseOver,
  onMouseOut
}) => {
  const circleRef = useRef();
  return (
    <>
      <circle
        key="point"
        ref={circleRef}
        cx={x}
        cy={y}
        r={size / 2}
        fill={fill}
        stroke={stroke}
        strokeWidth={strokeWidth}
        onMouseEnter={onMouseEnter}
        onMouseLeave={onMouseLeave}
        onMouseOver={onMouseOver}
        onMouseOut={onMouseOut}
      />
      <Tooltip
        key="tooltip"
        parent={circleRef}
        active={tooltipActive}
        {...tooltipStyle}
      >
        {tooltip}
      </Tooltip>
    </>
  );
};

export default Point;

import React from "react";
import LinePath from "./LinePath";
import scaleValue from "../helpers/scaleLinear";

const LineGraph = ({
  x = 0,
  y = 0,
  width = 100,
  height = 100,
  stroke = "#0000FF",
  strokeWidth = 2,
  strokeDasharray,
  bezier = false,
  data,
  xKey = "x",
  xMin = 0,
  filterXMin = 1,
  filterXMax = 12,
  xMax = 13,
  yKey = "y",
  yMin = 0,
  yMax = 100
}) => {
  const points = data
    .filter(
      dataItem =>
        (filterXMin === undefined || dataItem[xKey] >= filterXMin) &&
        (filterXMax === undefined || dataItem[xKey] <= filterXMax)
    )

    .map((dataItem, index) => {
      let x1 = scaleValue(dataItem[xKey], 0, width, xMin, xMax) + x;

      let pointVert = scaleValue(dataItem[yKey], 0, height, yMin, yMax - yMin);
      let y1 = height - pointVert + y;

      return [x1, y1];
    });

  return (
    <g>
      <LinePath
        width={width}
        height={height}
        stroke={stroke}
        strokeWidth={strokeWidth}
        strokeDasharray={strokeDasharray}
        points={points}
        bezier={bezier}
      />
    </g>
  );
};

export default LineGraph;

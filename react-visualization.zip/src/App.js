import React from "react";
import "./App.css";
import LineGraph from "./components/Visualizations/LineGraph/LineGraph";
import BarGraph from "./components/Visualizations/BarGraph/BarGraph";

function App() {
  return (
    <div id="App" style={{ margin: "10px" }}>
      <svg width={240} height={200} viewPort={`0 0 240 200`}>
        <BarGraph
          x={0}
          y={0}
          width={240}
          height={200}
          defaultColor={"red"}
          tooltip="hello"
        />
        <LineGraph
          x={0}
          y={0}
          width={240}
          height={200}
          defaultColor={"red"}
          tooltip="hello"
        />
      </svg>
      <svg width={240} height={200} viewPort={`0 0 240 200`}></svg>
    </div>
  );
}

export default App;

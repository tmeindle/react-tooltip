import React, { useRef } from "react";
import Point from "./Point";
import Tooltip from "../../Tooltip/Tooltip";

import pathString from "../svgHelpers/pathString";
const normalizeValue = (value, minNorm, maxNorm, minValue, maxValue) => {
  return (
    ((maxNorm - minNorm) / (maxValue - minValue)) * (value - minValue) +
    minValue
  );
};

const mockData = [
  { x: 1, y: 58 },
  { x: 2, y: 47 },
  { x: 3, y: 55 },
  { x: 4, y: 42 },
  { x: 5, y: 65 },
  { x: 6, y: 55 },
  { x: 7, y: 62 },
  { x: 8, y: 82 },
  { x: 9, y: 75 },
  { x: 10, y: 53 },
  { x: 11, y: 66 },
  { x: 12, y: 100 }
];

const Path = ({
  stroke = "#0000FF",
  strokeWidth = 2,
  strokeDasharray,
  points,
  tooltip,
  bezier = false,
  tooltipProps = {}
}) => {
  const pathRef = useRef();
  return (
    <g>
      <path
        key="line"
        ref={pathRef}
        d={pathString(points, bezier)}
        fill="none"
        strokeWidth={strokeWidth}
        stroke={stroke}
        strokeDasharray={strokeDasharray}
      />
      {tooltip ? <Tooltip {...tooltipProps}>{tooltip}</Tooltip> : null}
    </g>
  );
};

const LineGraph = ({
  width = 240,
  height = 200,
  stroke = "#0000FF",
  strokeWidth = 2,
  strokeDasharray,
  yKey = "y",
  yMin = 0,
  yMax = 100,
  data = mockData,
  tooltip = "tooltip",
  showPoints = false,
  pointSize = 3,
  pointColor = "#FF0000"
}) => {
  const sectionWidth = width / data.length;
  const points = data.reduce((array, dataItem, index) => {
    //let x = index * sectionWidth + (sectionWidth / 2 - strokeWidth / 2);
    let x = normalizeValue(index, 0, width, 0, data.length) + sectionWidth / 2;
    let pointHeight = normalizeValue(dataItem[yKey], 0, height, yMin, yMax);
    let y = height - pointHeight;
    array.push([x, y]);
    return array;
  }, []);
  return (
    <g>
      <Path
        width={width}
        height={height}
        stroke={stroke}
        strokeWidth={strokeWidth}
        strokeDasharray={strokeDasharray}
        points={points}
      />

      {points.map(([x, y], index) => {
        return (
          <Point
            key={`point` + index}
            x={x}
            y={y}
            size={pointSize}
            fill={showPoints ? pointColor : "transparent"}
            stroke={"none"}
            strokeWidth={0}
            tooltip={tooltip}
            pointColor={pointColor}
          />
        );
      })}
    </g>
  );
};

export default LineGraph;

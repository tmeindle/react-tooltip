import React, { useState, useRef } from "react";
import Tooltip from "../../Tooltip/Tooltip";

const Point = ({
  x,
  y,
  stroke = "black",
  strokeWidth = 1,
  fill = "red",
  size = 5,
  hoverSize = 20,
  tooltip = "hello"
}) => {
  const circleRef = useRef();
  const [hover, setHover] = useState(false);
  const tip = tooltip ? (
    <>
      <circle
        key="tooltipHitBox"
        cx={x}
        cy={y}
        r={hoverSize !== undefined ? hoverSize / 2 : size / 2}
        fill="transparent"
        onMouseEnter={() => setHover(true)}
        onMouseLeave={() => setHover(false)}
      />
      <Tooltip key="tooltip" parent={circleRef} active={hover && tooltip}>
        {tooltip}
      </Tooltip>
    </>
  ) : null;

  return (
    <>
      <circle
        ref={circleRef}
        key="datapoint"
        cx={x}
        cy={y}
        r={size / 2}
        fill={fill}
        stroke={stroke}
        strokeWidth={strokeWidth}
      />
      {tip}
    </>
  );
};

export default Point;

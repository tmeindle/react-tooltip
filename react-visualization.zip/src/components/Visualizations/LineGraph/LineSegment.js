import React, { useState } from "react";
import Tooltip from "../../Tooltip/Tooltip";

const LineSegment = ({
  dataItem,
  color = "black",
  tooltip = null,
  x1,
  y1,
  x2,
  y2
}) => {
  const [hover, setHover] = useState(false);
  const barRef = React.createRef();

  const onMouseEnter = () => setHover(true);
  const onMouseLeave = () => setHover(false);

  let rect = (
    <Rect
      key="rect"
      ref={barRef}
      x={x}
      y={y}
      width={width}
      height={height}
      fill={dataItem && dataItem[colorKey] ? dataItem[colorKey] : defaultColor}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
    />
  );

  let hoverIndicator = (
    <Rect
      key="hover-rect"
      x={x}
      y={y}
      width={width}
      height={height}
      fill="transparent"
      stroke="black"
      strokeWidth={1}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
    />
  );

  return (
    <>
      {rect}
      {hover ? hoverIndicator : null}
      <Tooltip
        key="tooltip"
        parent={barRef}
        active={hover && tooltip}
        position="right"
      >
        {tooltip}
      </Tooltip>
    </>
  );
};

export default LineSegment;

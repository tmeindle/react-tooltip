import React, { useState } from "react";
import Tooltip from "../../Tooltip/Tooltip";

const Bar = ({
  dataItem,
  defaultColor = "black",
  colorKey = "color",
  tooltip = null,
  x,
  y,
  height,
  width
}) => {
  const [hover, setHover] = useState(false);
  const barRef = React.createRef();

  const onMouseEnter = () => setHover(true);
  const onMouseLeave = () => setHover(false);

  let rect = (
    <rect
      key="rect"
      ref={barRef}
      x={x}
      y={y}
      width={width}
      height={height}
      fill={dataItem && dataItem[colorKey] ? dataItem[colorKey] : defaultColor}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
    />
  );

  let hoverIndicator = (
    <rect
      key="hover-rect"
      x={x}
      y={y}
      width={width}
      height={height}
      fill="transparent"
      stroke="black"
      strokeWidth={1}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
    />
  );

  return (
    <>
      {rect}
      {hover ? hoverIndicator : null}
      <Tooltip key="tooltip" parent={barRef} active={hover && tooltip}>
        {tooltip}
      </Tooltip>
    </>
  );
};

export default Bar;

import React from "react";
import Bar from "./Bar";
const normalizeValue = (value, minNorm, maxNorm, minValue, maxValue) => {
  return (
    ((maxNorm - minNorm) / (maxValue - minValue)) * (value - minValue) +
    minValue
  );
};

const mockData = [
  { x: 1, y: 58, color: "#FF00FF" },
  { x: 2, y: 47 },
  { x: 3, y: 55 },
  { x: 4, y: 42 },
  { x: 5, y: 65 },
  { x: 6, y: 55 },
  { x: 7, y: 62 },
  { x: 8, y: 82 },
  { x: 9, y: 75 },
  { x: 10, y: 53 },
  { x: 11, y: 66 },
  { x: 12, y: 100 }
];

const BarGraph = ({
  x = 0,
  y = 0,
  width = 240,
  height = 200,
  barWidth = 10,
  defaultColor = "#0000FF",
  valueKey = "y",
  colorKey = "color",
  data = mockData
}) => {
  const sectionWidth = width / data.length;
  return (
    <g>
      {data.map((dataItem, index) => {
        let barHeight = normalizeValue(dataItem[valueKey], 0, height, 0, 100);
        let x1 = index * sectionWidth + (sectionWidth / 2 - barWidth / 2); //+ x;
        let y1 = height - barHeight; // + y;
        return (
          <Bar
            key={index}
            x={x1}
            y={y1}
            width={barWidth}
            height={barHeight}
            dataItem={dataItem}
            defaultColor={defaultColor}
            tooltip="heldsffsadfsadlo"
          />
        );
      })}
    </g>
  );
};

export default BarGraph;

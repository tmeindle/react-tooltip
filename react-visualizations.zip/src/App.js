import React from "react";
import "./App.css";
import LineGraph from "./components/Visualizations/LineGraph/LineGraph";
import BarGraph from "./components/Visualizations/BarGraph/BarGraph";
import Pie from "./components/Visualizations/PieChart/Pie";
const mockData = [
  { x: 0, y: 65, color: "#FF00FF" },
  { x: 1, y: 58, color: "#FF00FF" },
  { x: 2, y: 47 },
  { x: 3, y: 55 },
  { x: 4, y: 42 },
  { x: 5, y: 65 },
  { x: 6, y: 55 },
  { x: 7, y: 62 },
  { x: 8, y: 82 },
  { x: 9, y: 75 },
  { x: 10, y: 53 },
  { x: 11, y: 66 },
  { x: 12, y: 100 },
  { x: 13, y: 87 }
];

const mockPieData = [
  { category: "A", percentage: 70 },
  { category: "B", percentage: 120 },
  { category: "C", percentage: 380 },
  { category: "D", percentage: 480 }
];

function App() {
  return (
    <div id="App" style={{ margin: "10px" }}>
      <div id="App" style={{ margin: "10px" }}>
        <svg width={1240} height={200} viewBox={`0 0 1240 200`}>
          <BarGraph
            x={0}
            y={0}
            width={240}
            height={200}
            scaleYMax={100}
            scaleXMin={1}
            scaleXMax={12}
            defaultColor={"red"}
            tooltip="hello"
            data={mockData}
          />
        </svg>
      </div>
      <div id="App" style={{ margin: "10px" }}>
        <svg width={240} height={200}>
          <LineGraph
            x={0}
            y={0}
            width={240}
            height={200}
            scaleYMax={100}
            scaleXMin={1}
            scaleXMax={12}
            defaultColor={"red"}
            tooltip="line"
            data={mockData}
          />
        </svg>
      </div>
      <div id="App" style={{ margin: "10px" }}>
        <svg width={240} height={200}>
          <BarGraph
            x={0}
            y={0}
            width={240}
            height={200}
            scaleYMax={100}
            scaleXMin={1}
            scaleXMax={12}
            defaultColor={"red"}
            data={mockData}
            tooltip="bar"
          />
          <LineGraph
            x={0}
            y={0}
            width={240}
            height={200}
            scaleYMax={100}
            scaleXMin={1}
            scaleXMax={12}
            defaultColor={"red"}
            data={mockData}
            tooltip="line"
          />
        </svg>
      </div>
      <div id="App" style={{ margin: "10px" }}>
        <svg width={200} height={200}>
          <Pie data={mockPieData} size={200} />
        </svg>
      </div>
    </div>
  );
}

export default App;

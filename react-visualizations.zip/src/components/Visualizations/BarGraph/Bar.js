import React, { useState } from "react";
import Tooltip from "../Tooltip/Tooltip";

const Bar = ({
  x,
  y,
  height,
  width,
  fill = "black",
  stroke = "black",
  strokeWidth = 0.5,
  tooltip = null
}) => {
  const [hover, setHover] = useState(false);
  const barRef = React.createRef();

  const onMouseEnter = () => setHover(true);
  const onMouseLeave = () => setHover(false);

  let rect = (
    <rect
      key="rect"
      ref={barRef}
      x={x + strokeWidth / 2}
      y={y + strokeWidth / 2}
      width={width - strokeWidth}
      height={height - strokeWidth}
      stroke={stroke}
      strokeWidth={strokeWidth}
      fill={fill}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
    />
  );

  let hoverIndicator = (
    <rect
      key="hover-rect"
      x={x + 0.5}
      y={y + 0.5}
      width={width - 1}
      height={height - 1}
      fill="black"
      stroke="black"
      strokeWidth={1}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
    />
  );

  return (
    <>
      {rect}
      {hover ? hoverIndicator : null}
      <Tooltip key="tooltip" parent={barRef} active={hover && tooltip}>
        {tooltip}
      </Tooltip>
    </>
  );
};

export default Bar;

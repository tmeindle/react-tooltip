import React from "react";
import Bars from "./Bars";
const scaleValue = (value, minNorm, maxNorm, minValue, maxValue) => {
  return (
    ((maxNorm - minNorm) / (maxValue - minValue)) * (value - minValue) +
    minValue
  );
};

const BarGraph = ({
  x = 0,
  y = 0,
  width = 100,
  height = 100,
  barWidth = 5,
  data,
  yKey = "y",
  scaleYMin = 0,
  scaleYMax = 100,
  xKey = "x",
  scaleXMin = 0,
  scaleXMax = 100,
  colorKey = "color",
  defaultColor = "#FF00FF",
  tooltip
}) => {
  const scaleX = scaleXMin + (scaleXMax - scaleXMin) + 1;
  const bars = data.map((dataItem, index) => {
    let x1 =
      scaleValue(dataItem[xKey], 0, width, scaleXMin, scaleX) +
      width / (scaleX - scaleXMin) / 2 -
      barWidth / 2 +
      x;

    let barHeight = scaleValue(
      dataItem[yKey] - 0.5,
      0,
      height,
      scaleYMin,
      scaleYMax - scaleYMin + 1
    );
    //let x1 = index * sectionWidth + (sectionWidth / 2 - barWidth / 2) + x;
    let y1 = height - barHeight + y;
    return [
      x1,
      y1,
      barWidth,
      barHeight,
      dataItem[colorKey] ? dataItem[colorKey] : defaultColor
    ];
  });

  return <Bars bars={bars} tooltip={tooltip} />;
};

export default BarGraph;

//based on:
//https://medium.com/@francoisromain/smooth-a-svg-path-with-cubic-bezier-curves-e37b49d46c74

const lineCommand = point => `L ${point[0]} ${point[1]}`;

const path = (points, command) => {
  // build the d attributes by looping over the points
  const d = points.reduce(
    (pathString, point, index, arr) =>
      index === 0
        ? // if first point
          `M ${point[0]},${point[1]}`
        : // else
          `${pathString} ${command(point, index, arr)}`,
    ""
  );
  return d;
};

const opposedLine = (pointA, pointB) => {
  const lengthX = pointB[0] - pointA[0];
  const lengthY = pointB[1] - pointA[1];
  return {
    length: Math.sqrt(Math.pow(lengthX, 2) + Math.pow(lengthY, 2)),
    angle: Math.atan2(lengthY, lengthX)
  };
};

// Position of a control point
// I:  - current (array) [x, y]: current point coordinates
//     - previous (array) [x, y]: previous point coordinates
//     - next (array) [x, y]: next point coordinates
//     - reverse (boolean, optional): sets the direction
// O:  - (array) [x,y]: a tuple of coordinates
const controlPoint = (current, previous, next, reverse) => {
  // When 'current' is the first or last point of the array
  // 'previous' or 'next' don't exist.
  // Replace with 'current'
  const p = previous || current;
  const n = next || current;
  // The smoothing ratio
  const smoothing = 0.2;
  // Properties of the opposed-line
  const opposed = opposedLine(p, n);
  // If is end-control-point, add PI to the angle to go backward
  const angle = opposed.angle + (reverse ? Math.PI : 0);
  const length = opposed.length * smoothing;
  // The control point position is relative to the current point
  const x = current[0] + Math.cos(angle) * length;
  const y = current[1] + Math.sin(angle) * length;
  return [x, y];
};

const bezierCommand = (point, i, a) => {
  // start control point
  const [cpsX, cpsY] = controlPoint(a[i - 1], a[i - 2], point);
  // end control point
  const [cpeX, cpeY] = controlPoint(point, a[i - 1], a[i + 1], true);
  return `C ${cpsX},${cpsY} ${cpeX},${cpeY} ${point[0]},${point[1]}`;
};

export const linePath = points => {
  path(points, lineCommand);
};

export const bezierPath = points => {
  path(points, bezierCommand);
};

export const pathString = (points, bezier = false) => {
  return path(points, bezier ? bezierCommand : lineCommand);
};
export default pathString;

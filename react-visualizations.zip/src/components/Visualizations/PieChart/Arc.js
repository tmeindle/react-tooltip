import React from "react";
import arcString from "../svgHelpers/arcString";
const Arc = ({
  startAngle,
  endAngle,
  outerRadius,
  innerRadius,
  stroke,
  strokeWidth,
  strokeOpacity,
  fill
}) => {
  const start = startAngle; // * 2 * Math.PI) / 360;
  const end = endAngle; // * 2 * Math.PI) / 360;
  return (
    <path
      d={arcString(start, end, outerRadius, innerRadius, strokeWidth)}
      stroke={stroke}
      strokeWidth={strokeWidth}
      strokeOpacity={strokeOpacity}
      fill={fill}
    />
  );
};

export default Arc;
